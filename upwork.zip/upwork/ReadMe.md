Press ctrl + shift + v for better view
# Setup for Upwork Chrome Extension

Below are the steps for the setup:

Step 1: Python Installation

```
- Navigate to [link](https://www.python.org)
- Hover over downloads, there is an option **Download for mac os**, click on Python 3.12.0.
- Click on the file downloaded, and follow the process by agreeing to the terms and conditions.
```


Step 2: Visual Studio Code Installation

```
- Navigate to [link](https://code.visualstudio.com/download)
- Download it for Mac By finding Mac option.
- Click on downloaded zip file and follow the process. And then open the visual studio code. 
```

Step2: Extension Installation

```
- Unzip the zip file by clicking on file given i.e upwork.zip.
- Open the Unzipped folder within visual studio code.
- Navigate to view on top in vs code and click on terminal(This is basically visual studio code terminal).
- Create and activate Virtual Environment by pasting command in visual studio code terminal one by one:
    1) python3 -m venv myenv
    2) source myenv/bin/activate
- Install dependencies using command:
    pip install -r requirements.txt
- In Visual studio code terminal, you'll see a (+) sign to add one more terminal, add it and in the right panel of terminal you can see 2 terminals we are using, you may switch between terminals from there.
- Hit the below command in the new opened terminal:
    /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222 --user-data-dir="$HOME/Library/Application Support/Google/Chrome/Default/"

    This will open your chrome browser automatically.
- In search type chrome://extensions and press enter.
- Enable the developer mode there in right corner.
- Click on load unpacked.
- Select the upwork folder then click on select. It will upload the extension.
**Important Note** : Don't open more then 1 tab in chrome, all work have to be done in one and the same tab.
- Now paste the link in the same tab https://www.upwork.com/ and login, **make sure to click remember me during login**.
- Navigate to  archieved proposals over there.example: https://www.upwork.com/ab/proposals/1026837743769149441
- Now go back to terminal, and in the other terminal hit the below command:
    **python3 app.py**
    - If you face any issue, try this, otherwise move ahead:
        - Go to 'System Preferences' on your Mac.
        - Click on 'Sharing.'
        - Uncheck the 'AirPlay Receiver' service.
        - Now again hit python3 app.py
- Now you can use the extension on the page.

**Important Note** : Don't open more then 1 tab in chrome, all work have to be done in one and the same tab.

```

