import os
import sys
import requests
import time
import openpyxl

from datetime import datetime
from openpyxl.styles import Font

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options


if len(sys.argv) >= 2:
    url = sys.argv[1]
    print(f"Scraping URL: {url}")
else:
    print("No URL provided.")

chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
headers = ['Business Manager', 'Sent from', 'Source', 'Location', 'Template Used', 'Project Name as it appears on site',
                       'Posted Date', '# of Proposals', 'Project Hourly Rate',
                       'Our Hourly Rate', 'Project Duration', 'Fixed Price', 'Date', 'Boosted?',
                       'Boosted Differiental', 'Client Name as it appears on site.', 'Lead', 'Good Lead', 'Client']
today_date = datetime.now().strftime('%-m/%-d/%Y')
driver = webdriver.Chrome(options=chrome_options)
# print('1111111')
driver.get(url)
# print('2222222')
driver.execute_script("alert('Start Scraping');")
time.sleep(10)
# print('33333')
driver.implicitly_wait(10)
upwork = {}


fields = {
    'Business Manager': None,
    'Sent from': None,
    'Source': None,
    'Location': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[2]/div[1]/div[4]/span[1]',
    'Template Used': None,
    'Project Name as it appears on site.': "/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[1]/h3",
    'Posted Date': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[1]/ul/li[2]',
    '# of Proposals': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[2]/div[1]/div[4]/div[1]/div',
    'Project Hourly Rate': '/html/body/div[3]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/section/div[1]/div[2]/ul/li[2]/div/div[2]',
    'Our Hourly Rate': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[3]/div[2]/div[1]/div[1]/div[2]',
    'Project Duration': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[2]/ul/li[3]/div/strong',
    'Fixed Price': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[2]/ul/li[2]/small',
    'Date': None,
    'Boosted?': None,
    'Boosted Differiental': None,
    'Client Name as it appears on site.': None,
    'Lead': None,
    'Good Lead': None,
    'Client' : None,
    'Project Length': '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[2]/ul/li[3]/small/span[1]'
}

def get_data():
    for field, xpath in fields.items():
        try:
            value = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, xpath))).text
            
        except NoSuchElementException:
            value = '' 
        except:
            value = ''
        upwork[field] = value
    if upwork['Project Length'] == 'Project Length':
        upwork['Project Duration'] = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[1]/div[2]/ul/li[3]/div/strong'))).text
    else:
        upwork['Project Duration'] = ''

    if upwork['Fixed Price'] == 'Hourly':
        upwork['Fixed Price'] = 'N/A'
        if upwork['Our Hourly Rate'] == '':
            try:
                upwork['Our Hourly Rate'] = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[3]/div[2]/div[1]/div[1]/div[2]'))).text
            except NoSuchElementException:
                upwork['Our Hourly Rate'] = ''
            except TimeoutException:
                upwork['Our Hourly Rate'] = ''
    else:
        try:                                                   
            upwork['Fixed Price'] = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.XPATH, '/html/body/div[4]/div/up-app/div/div/main/div[2]/div[4]/div/div[2]/div/div/div[1]/div[1]/div/div/section/div[3]/div[2]/div/div[2]/div[2]'))).text
        except NoSuchElementException:
            upwork['Fixed Price'] = 'N/A'
        except TimeoutException:
            upwork['Fixed Price'] = 'N/A'
    upwork['Date'] = today_date
    print(666666666666666666, upwork)
    # breakpoint()
    return upwork


def insert_into_sheet(upwork, url, headers):
    try:
        if not os.path.exists('Outbound Leads.xlsx'):
            workbook = openpyxl.Workbook()
            workbook.remove(workbook.active)  # Remove the default sheet created by openpyxl
            sheet = workbook.active
        else:
            workbook = openpyxl.load_workbook('Outbound Leads.xlsx')

        # Check if the sheet already exists; if not, create a new one
        sheet_name = "New - Bid & Lead Tracker - 2023"
        if sheet_name not in workbook.sheetnames:
            sheet = workbook.create_sheet(sheet_name)
            
            # Add headers if the sheet is newly created
            sheet.append(headers)
            for cell in sheet[1]:
                cell.font = Font(bold=True)
        else:
            sheet = workbook[sheet_name]

        # Add data from the list
        data_row = [upwork['Business Manager'], upwork['Sent from'], upwork['Source'],
                    upwork['Location'], upwork['Template Used'], upwork['Project Name as it appears on site.'],
                    upwork['Posted Date'], upwork['# of Proposals'], upwork['Project Hourly Rate'],
                    upwork['Our Hourly Rate'], upwork['Project Duration'], upwork['Fixed Price'],
                    upwork['Date'], upwork['Boosted?'], upwork['Boosted Differiental'],
                    upwork['Client Name as it appears on site.'], upwork['Lead'], upwork['Good Lead'], upwork['Client']]
        sheet.append(data_row)

        cell = sheet.cell(row=sheet.max_row, column=headers.index('Project Name as it appears on site') + 1)

        # Create a hyperlink to the URL
        cell.hyperlink = url
        cell.value = upwork['Project Name as it appears on site.']
        # Save the workbook with the data
        workbook.save('Outbound Leads.xlsx')
        print("Data saved to Excel successfully")
        driver.execute_script("alert('Data scraped and saved to excel successfully');")
        time.sleep(10)
        driver.quit()
    except Exception as e:
        print(f"Error: {str(e)}")




upwork_data = get_data()
insert_into_sheet(upwork_data, url, headers)
driver.quit()
