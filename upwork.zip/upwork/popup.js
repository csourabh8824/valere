$(function () {
  $('#runScriptButton').click(function () {
    // Show loader before sending the message
    $('body').hide();
    $('#loader').show();

    chrome.runtime.sendMessage(
      { action: 'startScraping' },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError.message);
          // Hide the loader in case of an error
          $('#loader').hide();
          return; // Exit if an error occurred
        }

        if (response && response.farewell) {
          var result = response.farewell;
          alert(result.summary);

          var notifOptions = {
            type: "basic",
            iconUrl: "icon48.png",
            title: "WikiPedia Summary For Your Result",
            message: result.summary // Using the summary from the response
          };

          chrome.notifications.create('WikiNotif', notifOptions);
        } else {
          console.error("Unexpected response format or missing 'farewell' property");
        }

        // Hide the loader after receiving the response
        $('#loader').hide();
      }
    );
  });
});
