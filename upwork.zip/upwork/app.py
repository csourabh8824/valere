import subprocess
from flask import Flask, request

app = Flask(__name__)

connected_clients = set()


@app.route('/run_selenium_script', methods=['GET'])
def run_selenium_script():
    url = request.args.get('url')
    try:
        # Modify your Selenium script to use the provided URL if needed
        subprocess.Popen(['python3', 'upwork.py', url])
        return "Selenium script is running."
    except Exception as e:
        return str(e)

@app.route('/hello', methods=['GET'])
def hello():
    return "Hello"
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
