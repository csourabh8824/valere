chrome.runtime.sendMessage(
    {action: 'startScraping'},
    function(response) {
      result = response.farewell;
      alert(result);
      
      var notifOptions = {
        type: "basic",
        iconUrl: "icon48.png",
        title: "WikiPedia Summary For Your Result",
        message: "WikiPedia Summary For Your Result"
      };
      chrome.notifications.create('WikiNotif', notifOptions);
      
    });




/*chrome.runtime.sendMessage(
    { action: 'startScraping' },
    function (response) {
        console.log(response);
        //return true;
    }
);*/