from django.urls import path
from .views import (
    CreateNotificationView, UpdateNotificationReadView, UnreadNotificationsListView,
    ReadNotificationsListView,
)


urlpatterns = [
    path('add', CreateNotificationView.as_view(), name='add-notification'),
    path('<int:pk>/read', UpdateNotificationReadView.as_view(), name='update-notification-read'),
    path('read/', ReadNotificationsListView.as_view(), name='read-notifications-list'),
    path('unread/', UnreadNotificationsListView.as_view(), name='unread-notifications-list'),
]
