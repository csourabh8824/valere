from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.generics import CreateAPIView, UpdateAPIView, ListAPIView

from .models import Notifications
from .serializers import NotificationReadSerializer, NotificationsSerializer


class CreateNotificationView(CreateAPIView):
    '''
        To create notification
    '''
    serializer_class = NotificationsSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                self.perform_create(serializer)
                return Response(
                    data={'data': None, 'message': 'Notification added successfully', 'errors': None},
                    status=status.HTTP_200_OK
                )
            return Response(
                data={'data': None, 'message': 'Invalid data', 'errors': serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def perform_create(self, serializer):
        serializer.save()


class UpdateNotificationReadView(UpdateAPIView):
    '''
    It updates read field from 0 to 1 if user reads the notification.
    '''
    queryset = Notifications.objects.all()
    serializer_class = NotificationReadSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            
            response_data = {
                'data': None,
                'message': 'Notification read/unread updated successfully',
                'errors': None
            }
            
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                'data': None,
                'message': str(e),
                'errors': None
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ReadNotificationsListView(ListAPIView):
    '''
    It provides the list of all the notifications that are read by user
    '''
    serializer_class = NotificationsSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user_id = self.request.user.id  
        return Notifications.objects.filter(user_id=user_id, read=1)

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            
            response_data = {
                "data": serializer.data, 
                "message": None,  
                "errors": None, 
            }
            
            return Response(data=response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                "data": None,
                "message": "Error in retrieving read notifications",
                "errors": str(e),
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

class UnreadNotificationsListView(ListAPIView):
    '''
    It provides the list of all the notifications that are unread by user
    '''
    serializer_class = NotificationsSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user_id = self.request.user.id  
        return Notifications.objects.filter(user_id=user_id, read=0)

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            
            response_data = {
                "data": serializer.data, 
                "message": None,  
                "errors": None, 
            }
            
            return Response(data=response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                "data": None,
                "message": "Error in retrieving unread notifications",
                "errors": str(e),
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        