from .models import Notifications
from rest_framework.serializers import ModelSerializer


class NotificationsSerializer(ModelSerializer):
    class Meta:
        model = Notifications
        fields = ['title', 'message']


class NotificationReadSerializer(ModelSerializer):
    class Meta:
        model = Notifications
        fields = ['read']