from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model

User = get_user_model()

class Notifications(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_id')
    send_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_notifications',
                                null=True)
    title = models.CharField(max_length=50, null=False)
    message = models.CharField(max_length=100, null=False)
    read = models.IntegerField(default=0, null=False)
    status = models.IntegerField(default=1, null=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'notifications'