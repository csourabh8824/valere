from django.urls import path
from .views import (
    GetPermissions, UserRolesPermissions, CreatePermissions, GetRoles, GetRole, 
    GetPermissionsByRole, RolesPermissionsUpdateView, GetUsers, GetUser, UserActiveInactive,
    PasswordUpdateView, UserUpdateView, CreateUserView
                    )


urlpatterns = [
    path('get-permissions', GetPermissions.as_view(), name='get-permissions'),
    path('createpermissions', CreatePermissions.as_view(), name='create-permissions'), # For developer use 
    path('get-roles', GetRoles.as_view(), name='all-roles'),
    path('get-role/<int:pk>', GetRole.as_view(), name='role-detail'),
    path('roles/<int:role_id>/permissions', GetPermissionsByRole.as_view(), name='get-permissions-by-roles'),
    path('create-roles-permissions', UserRolesPermissions.as_view(), name='create-roles-permissions'),
    path('update-roles-permissions/<int:pk>', RolesPermissionsUpdateView.as_view(), name='update-roles-permissions'),

    path('get-all', GetUsers.as_view(), name='all-users'),
    path('get/<int:pk>', GetUser.as_view(), name='user-detail'),
    path('user-active-inactive/<int:user_id>', UserActiveInactive.as_view(), name='user-active-inactive'),
    path('password-update', PasswordUpdateView.as_view(), name='password-update'),
    path('<int:user_id>/update', UserUpdateView.as_view(), name='user-update'),
    path('create-user', CreateUserView.as_view(), name='create-user'),
]
