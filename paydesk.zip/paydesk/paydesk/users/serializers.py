import re

from rest_framework import serializers
from .models import Roles, Permissions
from django.contrib.auth import get_user_model
from rest_framework.exceptions import ValidationError


User = get_user_model()

def match_password(password):
    regex = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
    if not re.match(regex, password):
        raise serializers.ValidationError("Password must contain 8 characters, 1 uppercase,"
                                          "1 lowercase, 1 digit and 1 special character")

class RolesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = ['name', 'key']


class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permissions
        # fields = '__all__'
        fields = ['id', 'name', 'key']



class PasswordUpdateSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True, required=True)
    new_password = serializers.CharField(write_only=True, required=True)

    def validate(self, data):
        user = self.context['request'].user

        # Check if the old password is correct
        if not user.check_password(data['old_password']):
            error_message = "Old password is incorrect."
            raise PasswordValidationError(data=None, message=error_message, errors=None)

        return data



class PasswordValidationError(ValidationError):
    def __init__(self, data=None, message=None, errors=None):
        detail = {"data": None, "message": message, "errors": None}
        super().__init__(detail=detail)


class UserUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['name']


class UserIsActiveSerializer(serializers.Serializer):
    is_active = serializers.BooleanField(required=True)


class AdminUserCreationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['name', 'email', 'password', 'is_active']  
    
    def validate_password(self, value):
        match_password(value)
        return value
    
    def validate_is_active(self, value):
        if value is None:
            raise serializers.ValidationError("is_active field is required")
        return value
    
    def create(self, validated_data):
        validated_data['status'] = 1  
        user = User(**validated_data)
        user.set_password(validated_data['password'])  
        user.save()
        return user