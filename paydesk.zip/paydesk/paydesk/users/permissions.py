from rest_framework.permissions import BasePermission

class IsAdminUserOrTargetUser(BasePermission):
    """
    Custom permission to allow admin to modify other users' is_active field.
    """

    def has_permission(self, request, view):
        # Check if the user is a admin
        return request.user and request.user.is_staff

    def has_object_permission(self, request, view, obj):
        # Allow admin to modify other users' is_active field
        return request.user and request.user.is_staff


class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.is_staff