import environ

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView, ListAPIView, RetrieveAPIView, UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import NotFound, PermissionDenied, ValidationError, AuthenticationFailed

from django.contrib.auth import get_user_model
from accounts.serializers import PayDeskUserSerializer
from django.core.mail import send_mail
from django.template.loader import render_to_string

from .pagination import RolePagination
from .models import Permissions, Roles, RolesPermissions
from .serializers import (RolesSerializer, PermissionSerializer, PasswordUpdateSerializer,
UserIsActiveSerializer, UserUpdateSerializer, AdminUserCreationSerializer)
from .exceptions.users_exception import RoleNotFoundException
from .permissions import IsAdminUserOrTargetUser, IsAdminUser

User = get_user_model()
env = environ.Env()
environ.Env.read_env()

class GetPermissions(APIView):
    def get(self, request):
        try:
            list_data = []
            items = Permissions.objects.all()
            for item in items:
                filtered_data = {
                    'id': item.id,
                    'name': item.name,
                    'key': item.key,
                }
                list_data.append(filtered_data)
            return Response(data={'data': list_data, 'message': None, 'errors': None}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'data': None, 'message': 'Data not found.', 'errors': None}, status=status.HTTP_200_OK)


class UserRolesPermissions(APIView):
    '''
    Roles and Permission creation
    '''

    def post(self, request):
        try:
            permission_ids = request.data['permissions']
            request.data.pop('permissions')
            serializer = RolesSerializer(data=request.data)
            
            if serializer.is_valid():
                serializer.save()
                role = Roles.objects.latest('created_at')
                
                roles_permissions_list = []
                for permission_id in permission_ids:
                    try:
                        permission = Permissions.objects.get(pk=permission_id)
                    except Permissions.DoesNotExist:
                        return Response(
                            {'data': None, 'message': f'Permission with ID {permission_id} not found', 'errors': None},
                            status=status.HTTP_404_NOT_FOUND)
                    
                    roles_permissions = RolesPermissions(role_id=role, permission_id=permission)
                    roles_permissions_list.append(roles_permissions)
                
                RolesPermissions.objects.bulk_create(roles_permissions_list)
                
                return Response(data={'data': 'created', 'message': 'Roles and Permissions Created', 'errors': None},
                                status=status.HTTP_200_OK)
            else:
                return Response({'data': None, 'message': 'Invalid data', 'errors': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'data': None, 'message': str(e), 'errors': None}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# For developer use only
class CreatePermissions(CreateAPIView):
    queryset = Permissions.objects.all()
    serializer_class = PermissionSerializer


class GetRoles(ListAPIView):
    serializer_class = RolesSerializer
    pagination_class = RolePagination
    
    def get_queryset(self):
        queryset = Roles.objects.all()
        return queryset
    
    def list(self, request, *args, **kwargs):
        try:
            queryset = self.get_queryset()
            serializer = self.get_serializer(queryset, many=True)
            
            data = {
                'data': serializer.data,
                'message': None,
                'errors': None
            }
            
            return Response(data=data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class GetRole(RetrieveAPIView):
    serializer_class = RolesSerializer

    def get_queryset(self):
        queryset = Roles.objects.all()
        return queryset
    
    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            
            data = {
                'data': serializer.data,
                'message': None,
                'errors': None
            }
            
            return Response(data=data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    

class GetPermissionsByRole(APIView):
    def get(self, request, role_id):
        try:
            role = Roles.objects.get(id=role_id)
        except Roles.DoesNotExist:
            return Response(data={'data': None, 'message':'Role not found', 'errors': None},
                status=status.HTTP_404_NOT_FOUND
            )
        role_permissions = RolesPermissions.objects.filter(role_id=role)
        permission_ids = role_permissions.values_list('permission_id', flat=True)

        # Retrieve the actual permissions using the permission IDs
        permissions = Permissions.objects.filter(id__in=permission_ids)

        serializer = PermissionSerializer(permissions, many=True)

        return Response(data={'data':serializer.data, 'message': 'Role and its permission retrieved successfully',
                              'errors': None}, status=status.HTTP_200_OK)
    


class RolesPermissionsUpdateView(UpdateAPIView):
    queryset = Roles.objects.all()
    serializer_class = RolesSerializer

    def get_object(self):
        try:
            role = super().get_object()
        except Roles.DoesNotExist:
            return Response(data={'data': None, 'message':'Role not found', 'errors': None},
                status=status.HTTP_404_NOT_FOUND
            )
        
        return role

    def update(self, request, *args, **kwargs):
        permissions_data = request.data.get('permissions', [])
        
        try:
            role = self.get_object()
            role.name = request.data.get('name', role.name)
            role.key = request.data.get('key', role.key)
            role.save()

            # Clear existing permissions through the RolesPermissions model
            RolesPermissions.objects.filter(role_id=role).delete()
            
            # Add new permissions through the RolesPermissions model
            for permission_id in permissions_data:
                try:
                    permission = Permissions.objects.get(pk=permission_id)
                except Exception as e:
                    return Response(
                        data={'data': None, 'message': f'Permission {permission_id} not found', 'errors': None},
                        status=status.HTTP_404_NOT_FOUND
                    )
                RolesPermissions.objects.create(role_id=role, permission_id=permission)
            
            return Response(
                data={'data': None, 'message': 'Role and permissions updated successfully', 'errors': None},
                status=status.HTTP_200_OK
            )
        except RoleNotFoundException:
            return Response(
                data={'data': None, 'message': 'Role not found', 'errors': None},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_400_BAD_REQUEST
            )


class GetUsers(ListAPIView):
    serializer_class = PayDeskUserSerializer
    permission_classes = [IsAdminUser]
    
    def get_queryset(self):
        queryset = User.objects.all()
        return queryset
    
    def list(self, request, *args, **kwargs):
        try:
            queryset = self.get_queryset()
            serializer = self.get_serializer(queryset, many=True)
            
            data = {
                'data': serializer.data,
                'message': None,
                'errors': None
            }
            
            return Response(data=data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class GetUser(RetrieveAPIView):
    serializer_class = PayDeskUserSerializer
    permission_classes = [IsAdminUser]

    def get_queryset(self):
        queryset = User.objects.all()
        return queryset
    
    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            
            data = {
                'data': serializer.data,
                'message': None,
                'errors': None
            }
            
            return Response(data=data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(
                data={'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

# For superuser
class UserActiveInactive(APIView):
    '''
    Allow superusers to modify other users' is_active field.
    '''
    permission_classes = [IsAdminUserOrTargetUser]

    def put(self, request, user_id):
        try:
            user = User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return Response(
                {'data': None, 'message': 'User not found', 'errors': None},
                status=status.HTTP_404_NOT_FOUND
            )

        # Use the custom serializer for is_active
        serializer = UserIsActiveSerializer(data=request.data)

        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError as e:
            # Handle validation errors with a 400 response
            return Response(
                {'data': None, 'message': e.detail, 'errors': None},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            if request.user.is_superuser:
                is_active = serializer.validated_data['is_active']
                user.is_active = is_active
                user.save()
                return Response(
                    {'data': None, 'message': f'Changes saved for user: {user.name}', 'errors': None},
                    status=status.HTTP_200_OK
                )
            else:
                return Response({'data': None, 'message': 'Invalid token.', 'errors': None},
                                status=status.HTTP_400_BAD_REQUEST)
        except AuthenticationFailed:
            # Handle authentication failures (invalid token) with a 403 response
            return Response(
                {'data': None, 'message': 'You do not have permission.', 'errors': None},
                status=status.HTTP_403_FORBIDDEN
            )




class PasswordUpdateView(UpdateAPIView):
    serializer_class = PasswordUpdateSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)

            # Update the user's password
            user = self.request.user
            user.set_password(serializer.validated_data['new_password'])
            user.save()

            return Response({'data': None,'message': 'Password updated successfully.', 'errors': None}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'data':None, 'message': str(e), 'errors': None}, status=status.HTTP_400_BAD_REQUEST)


class UserUpdateView(UpdateAPIView):
    serializer_class = UserUpdateSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        try:
            user_id = self.kwargs.get('user_id')  # Get the user's identifier from URL parameters

            try:
                user = User.objects.get(pk=user_id)  # Retrieve the user by ID
            except User.DoesNotExist:
                return Response({'data': None, 'message': 'User not found', 'errors': None}, status=status.HTTP_404_NOT_FOUND)

            serializer = self.get_serializer(user, data=request.data)
            serializer.is_valid(raise_exception=True)
            
            serializer.save()

            return Response({'data': None, 'message': 'Information updated successfully', 'errors': None})
        except Exception as e:
            return Response({'data':None, 'message': str(e), 'errors': None}, status=status.HTTP_400_BAD_REQUEST)


# Only admin can create
class CreateUserView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request):
        try:
            serializer = AdminUserCreationSerializer(data=request.data)
            if serializer.is_valid():
                user = serializer.save()
                subject = 'Successfully registered and Activated your account'
                message = f"Your email: {user.email}\nYour password: {request.data['password']}"
                from_email = env('EMAIL_HOST_USER')
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list, fail_silently=False)
                return Response(data={'data': None, 'message': f'Account created successfully for {user.name}',
                                      'errors': None}, status=status.HTTP_200_OK)
            else:
                return Response(data={'data': None, 'message':'Invalid data', 'errors': serializer.errors},
                                       status=status.HTTP_400_BAD_REQUEST)
        except PermissionDenied:
            return Response(
                {'data': None, 'message': 'You do not have permission to create a user.', 'errors': None},
                status=status.HTTP_403_FORBIDDEN
            )
        except Exception as e:
            return Response(
                {'data': None, 'message': str(e), 'errors': None},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
