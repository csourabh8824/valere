from django.contrib import admin
from .models import Roles,Permissions

# Register your models here.
@admin.register(Roles)
class PayDeskUserRegistrationAdmin(admin.ModelAdmin):
    list_display = ['name', 'key', 'created_at', 'updated_at']

@admin.register(Permissions)
class PayDeskUserRegistrationAdmin(admin.ModelAdmin):
    list_display = ['name', 'key', 'created_at', 'updated_at']
