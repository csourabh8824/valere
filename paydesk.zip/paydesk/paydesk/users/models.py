from django.db import models
from django.utils import timezone


# Create your models here.
class Roles(models.Model):
    name = models.CharField(max_length=20)
    key = models.CharField(max_length=20)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.IntegerField(default=1)

    class Meta:
        db_table = 'roles'


class Permissions(models.Model):
    name = models.CharField(max_length=20)
    key = models.CharField(max_length=20)  # invoice_create, invoice_edit
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'permissions'


class RolesPermissions(models.Model):
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT, null=True)
    permission_id = models.ForeignKey(Permissions, on_delete=models.PROTECT, null=True)

    class Meta:
        db_table = 'roles_permissions'


