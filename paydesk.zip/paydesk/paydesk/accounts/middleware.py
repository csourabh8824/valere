from django.http import JsonResponse
from cryptography.fernet import Fernet


class EncryptionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.secret_key = Fernet.generate_key()
        self.fernet = Fernet(self.secret_key)

    def __call__(self, request):
        if request.method == 'POST' and 'encrypted_data' in request.data:
            try:
                encrypted_data = request.data['encrypted_data']
                decrypted_data = self.fernet.decrypt(encrypted_data.encode()).decode()
                request.data = {**request.data, 'decrypted_data': decrypted_data}
            except Exception as e:
                return JsonResponse({'error': 'Decryption failed'}, status=400)

        response = self.get_response(request)

        if hasattr(response, 'data') and 'data' in response.data:
            encrypted_response = self.fernet.encrypt(response.data['data'].encode()).decode()
            response.data['data'] = encrypted_response

        return response

