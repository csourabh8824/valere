from Crypto.Cipher import AES
import base64
from django.http import JsonResponse

def decrypt_password(encrypted_password, key):
    try:
        # Decode the Base64-encoded encrypted password
        encrypted_bytes = base64.b64decode(encrypted_password)

        # Extract the IV (Initialization Vector) from the first 16 bytes
        iv = encrypted_bytes[:16]
        ciphertext = encrypted_bytes[16:]

        # Convert the key to bytes (assuming it's in UTF-8 encoding)
        key_bytes = key.encode('utf-8')

        # Create an AES cipher object with the key and IV
        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)

        # Decrypt the ciphertext
        decrypted_bytes = cipher.decrypt(ciphertext)

        # Remove padding (if any) and decode the result as UTF-8
        decrypted_password = decrypted_bytes.rstrip(b'\x00').decode('utf-8')

        return decrypted_password
    except Exception as e:
        return str(e)


data = decrypt_password("bqvGEzGblgtyxtVPBX2rgA8jtct8nRW8U/VUj8QQaWg=", "PASSWORD")
print(data)
