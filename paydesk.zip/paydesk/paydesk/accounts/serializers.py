import re
from django.urls import reverse
import environ
import phonenumbers

from django.utils import timezone
from rest_framework import serializers
from django.utils.encoding import force_bytes
from django.contrib.auth import get_user_model
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator

env = environ.Env()
environ.Env.read_env()


def match_password(password):
    regex = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
    if not re.match(regex, password):
        raise serializers.ValidationError("Password must contain 8 characters, 1 uppercase,"
                                          "1 lowercase, 1 digit and 1 special character")


class PhoneNumberField(serializers.CharField):
    def to_internal_value(self, data):
        try:
            parsed_number = phonenumbers.parse(data, None)
            if phonenumbers.is_valid_number(parsed_number):
                return phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)
            else:
                raise serializers.ValidationError("Invalid phone number")
        except phonenumbers.phonenumberutil.NumberParseException:
            raise serializers.ValidationError("Invalid phone number")


class PayDeskUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
        style={'input_type': 'password', }
    )

    # phone_number = PhoneNumberField()

    def validate_password(self, value):
        match_password(value)
        return value

    def create(self, validated_data):
        user = get_user_model().objects.create(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user

    class Meta:
        model = get_user_model()
        fields = ['name', 'email', 'password']


class UserActivationSerializer(serializers.Serializer):
    token = serializers.CharField()

    def validate_token(self, value):
        try:
            user = get_user_model().objects.get(activation_token=value, is_active=False)
            return value
        except get_user_model().DoesNotExist:
            raise serializers.ValidationError("Invalid activation token.")

    def check_user_activation(self):
        user = get_user_model().objects.get(activation_token=self.validated_data['token'])
        if user.status == 0:
            return True
        else:
            return False

    def activate_user(self):
        user = get_user_model().objects.get(activation_token=self.validated_data['token'])
        user.is_active = True
        user.is_staff = False
        user.status = 1
        # user.activation_token = None
        user.email_verified_at = timezone.now()
        user.save()


class PasswordResetSerializer(serializers.Serializer):
    email = serializers.EmailField()

    def validate_email(self, value):
        user = get_user_model().objects.filter(email=value).first()
        if not user:
            raise serializers.ValidationError("No account with this email address.")
        return value

    def save(self):
        email = self.validated_data['email']
        user = get_user_model().objects.get(email=email)
        # Generate a token and send a reset link to the user's email
        token = default_token_generator.make_token(user)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        reset_url = f"{env('FRONTEND_URL')}createpassword/{uid}/{token}"
        # reset_url = reverse('password-reset-confirm', args=[uid, token]) # for developer testing 
        return reset_url
