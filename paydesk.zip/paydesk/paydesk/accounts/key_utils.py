from Crypto.Cipher import AES
import base64


def decrypt_password(encrypted_password, key):
    try:
        # Initialize the AES cipher with the provided key
        cipher = AES.new(key.encode('utf-8'), AES.MODE_CBC)

        # Decode the base64-encoded encrypted password
        encrypted_bytes = base64.b64decode(encrypted_password)

        # Decrypt the password
        decrypted_password = cipher.decrypt(encrypted_bytes).decode('utf-8')

        # Remove any padding added during encryption
        decrypted_password = decrypted_password.rstrip('\0')

        return decrypted_password
    except Exception as e:
        # Handle decryption errors as needed
        return None
