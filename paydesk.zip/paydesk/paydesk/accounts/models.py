import uuid
import phonenumbers

from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.base_user import BaseUserManager

from users.models import Roles


class PhoneNumberField(models.CharField):
    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20  # Adjust the max length as needed
        kwargs['null'] = False
        super().__init__(*args, **kwargs)

    def to_python(self, value):
        try:
            parsed_number = phonenumbers.parse(value, None)
            if phonenumbers.is_valid_number(parsed_number):
                return phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)
        except phonenumbers.phonenumberutil.NumberParseException:
            pass
        return value

    def from_db_value(self, value, expression, connection):
        return self.to_python(value)

    def get_prep_value(self, value):
        return self.to_python(value)


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """
        Create and return a superuser with the given email, and password.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        return self.create_user(email, password, **extra_fields)


class PayDeskUser(AbstractUser):
    username = None
    first_name = None
    last_name = None
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT, default=2)
    name = models.CharField(max_length=100, null=False, )
    email = models.EmailField(max_length=50, null=False, unique=True)
    # phone_number = PhoneNumberField()
    status = models.IntegerField(default=0)
    is_active = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    activation_token = models.UUIDField(default=uuid.uuid4, editable=False, null=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(
        auto_now=True)  # This field will be automatically updated when the user model is saved
    email_verified_at = models.DateTimeField(default=timezone.now)
    password = models.CharField(max_length=100, null=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'password', ]

    class Meta:
        db_table = 'users'
