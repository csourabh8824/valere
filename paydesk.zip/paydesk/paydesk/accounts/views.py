import re
import logging
import environ
from rest_framework import status
from .key_utils import decrypt_password
from django.core.mail import send_mail
from rest_framework.views import APIView
from django.utils.encoding import force_str
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode
from rest_framework.exceptions import ValidationError
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth.tokens import default_token_generator
from rest_framework.permissions import IsAuthenticated
from rest_framework.generics import CreateAPIView, UpdateAPIView
from .serializers import PayDeskUserSerializer, UserActivationSerializer, \
    PasswordResetSerializer

User = get_user_model()
env = environ.Env()
environ.Env.read_env()


class PayDeskUserRegistrationAPI(CreateAPIView):
    '''
        User registration for paydesk
    '''
    queryset = User.objects.all()
    serializer_class = PayDeskUserSerializer

    def create(self, request, *args, **kwargs):
        # encrypted_password = request.data.get('password')
        # encryption_key = 'PASSWORD'
        # decrypted_password = decrypt_password(encrypted_password, encryption_key)
        # request.data['password'] = decrypted_password
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            try:
                user = serializer.save()
                verification_token = user.activation_token
                verification_url = f"{env('FRONTEND_URL')}activation/{verification_token}"
                subject = 'Activate your account'
                message = (f'Click the following link to activate your account: '
                           f'{verification_url}')
                from_email = 'sourabhchoudhary@valere.io'
                recipient_list = [user.email]
                email_message = render_to_string('accounts/registration_successful_email.html',
                                                 {'name': user.name, 'url': verification_url})
                send_mail(subject, message, from_email, recipient_list, html_message=email_message)
                logging.info('Email sent for the registration')
                logging.info(f"Account registered succsessfully for {serializer.validated_data['first_name']}")
                return Response(data={"data": None,
                                      "message": f"Account registered successfully for "
                                                 f"{serializer.validated_data['name']}, "
                                                 f'Account activation link sent on email',
                                      "errors": None},
                                status=status.HTTP_200_OK)
            except Exception as e:
                logging.error(f"Account registration fails")
                return Response(data={"data": None, "message": serializer.errors, "errors": None}, status=status.HTTP_400_BAD_REQUEST)
        else:
            logging.error(f"Account registration fails")
            return Response(data={"data": None, "message": serializer.errors, "errors": None},
                            status=status.HTTP_400_BAD_REQUEST)


class PayDeskUserActivationView(UpdateAPIView):
    '''
        Account activation view for user.
    '''

    queryset = User.objects.all()
    serializer_class = UserActivationSerializer

    def update(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            check_activation = serializer.check_user_activation()
            if check_activation:
                serializer.activate_user()
                logging.info('Account activated successfully.')
                return Response({'data': None, 'message': 'Account activated successfully.', 'errors': None},
                                status=status.HTTP_200_OK)
            else:
                logging.info('Account already activated.')
                return Response({'data': None, 'message': 'Account already activated.', 'errors': None},
                                status=status.HTTP_200_OK)
        except Exception as e:
            logging.error('Error in account activation: %s', e)
            return Response({'data': None, 'message': str(e), 'errors': None}, status=status.HTTP_400_BAD_REQUEST)


class PasswordResetRequestView(APIView):
    '''
    View to send password reset link to a user on email
    '''

    def post(self, request):
        try:
            serializer = PasswordResetSerializer(data=request.data, context={'request': request})
            if serializer.is_valid():
                reset_url = serializer.save()
                subject = 'Password Reset'
                message = (f"You can reset your password by clicking the following link:\n\n"
                           f"{reset_url}")
                from_email = serializer.validated_data['email']
                recipient_list = [serializer.validated_data['email']]
                email_message = render_to_string('accounts/password_reset_email.html',
                                                 {'url': f"{reset_url}"})
                send_mail(subject, message, from_email, recipient_list, html_message=email_message)
                logging.info('Email sent for the password reset')
                return Response({'data': None, 'message': 'Password reset link sent to your email.', 'errors': None},
                                status=status.HTTP_200_OK)
            logging.error(f'Error in processing request: {serializer.errors}')
            return Response(data={'data': None, 'message': serializer.errors, 'errors': None},
                            status=status.HTTP_400_BAD_REQUEST)
        except ValidationError as e:
            logging.error(f'Error in processing request: {e}')
            return Response({'data': None, "message": str(e), 'errors': None}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.error(f'Error in processing request: {e}')
            return Response({'data': None, 'message': str(e), 'errors': None},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PasswordResetConfirmView(APIView):
    '''
    View to reset password
    '''

    def post(self, request, uidb64, token):
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
            if default_token_generator.check_token(user, token):
                # encrypted_password = request.data.get('new_password')
                # encryption_key = 'PASSWORD'
                # decrypted_password = decrypt_password(encrypted_password, encryption_key)
                # request.data['new_password'] = decrypted_password
                new_password = request.data.get('new_password')
                regex = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
                if not re.match(regex, new_password):
                    return Response({'data': None, 'message': 'Password must contain 8 characters, 1 uppercase, '
                                                              '1 lowercase, 1 digit and 1 special character',
                                     'errors': None},
                                    status=status.HTTP_400_BAD_REQUEST)
                else:
                    user.set_password(new_password)
                    user.save()
                    logging.info('Password reset successful')
                    return Response({'data': None, 'message': 'Password reset successfully.', 'errors': None},
                                    status=status.HTTP_200_OK)
            else:
                logging.error('Invalid token')
                return Response({'data': None, 'message': 'Invalid token.', 'errors': None},
                                status=status.HTTP_400_BAD_REQUEST)
        except User.DoesNotExist:
            logging.error('User not found.')
            return Response({'data': None, 'message': 'User not found.', 'errors': None},
                            status=status.HTTP_400_BAD_REQUEST)


class LoginView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        try:
            response = super().post(request, *args, **kwargs)
            if response.status_code == 200:
                user = User.objects.get(email=request.data['email'])
                if user.is_active:
                    response.data['data'] = {
                        'access_token': response.data['access'],
                        'refresh_token': response.data['refresh'],
                        'name': user.name,
                        'email': user.email,
                    }
                    response.data['message'] = 'Successfully logged in'
                    response.data['errors'] = None
                    response.data.pop('access')
                    response.data.pop('refresh')
                else:
                    response.data['data'] = None
                    response.data['message'] = 'Account is not active'
                    response.data['errors'] = None
                    response.status_code = status.HTTP_403_FORBIDDEN
                return response
        except Exception as e:
            return self.handle_validation_error(e)

    def handle_validation_error(self, exceptions):
        if isinstance(exceptions, ValidationError):
            error_messages = {}
            for field, errors in exceptions.detail.items():
                field_errors = [str(error) for error in errors]
                error_messages[field] = field_errors

            response_data = {
                'data': None,
                'message': error_messages,
                'errors': None
            }
            return Response(data=response_data, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(data={'data': None, 'message': 'Please provide correct email or password', 'errors': None},
                            status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh_token = request.data.get('refresh_token')
        if not refresh_token:
            return Response({'data': None, 'message': 'Refresh token is required.', 'errors': None},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            RefreshToken(refresh_token).blacklist()
        except Exception as e:
            return Response({'data': None, 'message': str(e), 'errors': None}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'data': None, 'message': 'Successfully logged out.', 'errors': None},
                        status=status.HTTP_200_OK)


class TermsAndConditions(APIView):
    def get(self, request):
        try:
            return Response(data={'data': 'Development in progress', 'message': None, 'errors': None}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'data': None, 'message': 'Data not found.', 'errors': None}, status=status.HTTP_400_BAD_REQUEST)


class Support(APIView):
    def get(self, request):
        try:
            return Response(data={'data': 'Development in progress', 'message': None, 'errors': None}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'data': None, 'message': 'Data not found.', 'errors': None}, status=status.HTTP_400_BAD_REQUEST)


class CustomerCare(APIView):
    def get(self, request):
        try:
            return Response(data={'data': 'Development in progress', 'message': None, 'errors': None}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'data': None, 'message': 'Data not found.', 'errors': None}, status=status.HTTP_400_BAD_REQUEST)
