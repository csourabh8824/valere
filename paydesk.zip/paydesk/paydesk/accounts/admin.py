from django.contrib import admin
from .models import PayDeskUser


@admin.register(PayDeskUser)
class PayDeskUserRegistrationAdmin(admin.ModelAdmin):
    list_display = ['role_id', 'name', 'email', 'created_at',
                    'updated_at', 'email_verified_at', 'password', ]


