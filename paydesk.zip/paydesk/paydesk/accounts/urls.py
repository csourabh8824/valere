from django.urls import path
from rest_framework_simplejwt.views import (
    TokenRefreshView,
)

from .views import (
    PayDeskUserRegistrationAPI, PayDeskUserActivationView, PasswordResetRequestView,
    PasswordResetConfirmView, LoginView, LogoutView, TermsAndConditions, Support,
    CustomerCare
)


urlpatterns = [
    path('register', PayDeskUserRegistrationAPI.as_view(), name='registration'),
    path('activate', PayDeskUserActivationView.as_view(), name='activate'),
    path('login', LoginView.as_view(), name='login'),
    path('logout', LogoutView.as_view(), name='logout'),
    path('login/refresh', TokenRefreshView.as_view(), name='token_refresh'),
    path('password-reset', PasswordResetRequestView.as_view(), name='password-reset'),
    path('password-reset-confirm/<str:uidb64>/<str:token>', PasswordResetConfirmView.as_view(), name='password-reset-confirm'),

    path('terms-and-conditions', TermsAndConditions.as_view(), name='terms-and-conditions'),
    path('support', Support.as_view(), name='support'),
    path('customer-care', CustomerCare.as_view(), name='customer-care'),
]
